# Configuration settings
import os

# --- Secrets ---
# IMPORTANT: Store your OpenAI API Key securely. Do NOT hardcode it here.
# Option 1: Use Streamlit Secrets (recommended for deployed apps)
# Add it to your .streamlit/secrets.toml file:
# OPENAI_API_KEY = "sk-..."
# Then access it in your code: st.secrets["OPENAI_API_KEY"]
# Option 2: Use Environment Variables (good for local development)
# Set an environment variable named OPENAI_API_KEY
# Then access it in your code: os.getenv("OPENAI_API_KEY")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "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") # Replace placeholder if not using env var

# --- Step Configuration ---
# List of step names for the sidebar tracker
STEP_NAMES = [
    "Product Details",
    "Select Supplier",
    "Initial Message",
    "Await Response",
    "Assign Worker",
    "Send Confirmation",
    "Complete"
]

# --- File Paths ---
SUPPLIERS_FILE = "data/suppliers.json"
WORKERS_FILE = "data/workers.json"
# DB_FILE = "data/app_data.db" # Defined in db_init.py and data_handler.py

# --- Model Names ---
# Define model names here (can be overridden by secrets or env vars if needed)
LLM_MODEL = 'gpt-4o'
TEXT_TO_SPEECH_MODEL = "gpt-4o-mini-tts" # Example model names, adjust as needed
TRANSCRIPTION_MODEL = "gpt-4o-mini-transcribe" # Example model names, adjust as needed

# --- Email Configuration (PLACEHOLDERS - Currently Unused, Simulation Active) ---
# SMTP_SERVER = "smtp.example.com"  # Replace with your SMTP server
# SMTP_PORT = 587                   # Replace with your SMTP port (e.g., 587 for TLS, 465 for SSL)
# SMTP_USERNAME = "your_email@example.com" # Replace with your email username
# SMTP_PASSWORD = "your_app_password"      # Replace with your email password or App Password
# SENDER_EMAIL = "your_email@example.com" # Replace with your sender email address

# --- (Removed Previous Hardcoded Keys) ---
# Ensure no actual keys are present below this line.