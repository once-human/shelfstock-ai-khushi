import os
from datetime import datetime
from typing import List, Dict
import openai
import configs
from pydantic import BaseModel
from typing import List, Dict, Optional, Type, Union

"""
openai_api_helper.py

👋 About this file:
This module wraps the most common OpenAI API tasks into easy-to-use functions for students and designers
working on voice- or text-based AI prototypes.

It helps you interact with three types of AI functionality:
1. 🧠 generate_completion: Create AI responses from text prompts (chat, summaries, answers, etc.)
2. 🎙️ transcribe_audio: Convert recorded voice into text using speech-to-text
3. 🔊 synthesize_speech: Turn AI-generated text into spoken audio using text-to-speech

✨ Why use this?
You don’t need to know all the OpenAI API details. These helpers simplify everything and give you 
just what you need for fast prototyping in your projects.

📚 Example use case:
You record your voice → transcribe it → send it to the AI → get a text reply → play the reply back with audio.
This file makes all those steps easy.
"""

# ---------- OpenAI Client ----------

client = openai.OpenAI(api_key=configs.OPENAI_API_KEY)

# ---------- TEXT-TO-TEXT COMPLETION ----------

def generate_completion(
    message_history: List[Dict[str, str]],
    response_format: Optional[Type[BaseModel]] = None
) -> Union[str, BaseModel]:
    """
    Generates a response from the AI based on the given conversation history.

    This function sends a list of messages (from system, user, or assistant) to the OpenAI API,
    and receives a reply. If a structured response is expected (like JSON format), you can pass
    a Pydantic model to automatically parse and validate it.

    Args:
        message_history: A list of dictionaries containing the conversation so far.
                         Each message must have a 'role' (system, user, or assistant)
                         and a 'content' string.
        response_format: (Optional) A Pydantic BaseModel class to validate structured replies.

    Returns:
        Either a plain text response (str), or a parsed data object if a response_format is provided.

    Example:
        >>> message_history = [{"role": "system", "content": "You are a creative storyteller."}]
        >>> message_history.append({"role": "user", "content": "Tell me a short story about a cat."})
        >>> response = generate_completion(message_history)
        >>> print(response)
    """
    print("[generate_completion] Started generating AI response...")

    if response_format:
        response = client.beta.chat.completions.parse(
            model=configs.LLM_MODEL,
            messages=message_history,
            response_format=response_format
        )
        content = response.choices[0].message.content.strip()

        # Save assistant reply to memory
        message_history.append({"role": "assistant", "content": content})

        try:
            print("[generate_completion] Finished and parsed structured response.")
            return response_format.model_validate_json(content)
        except Exception as e:
            print("[Warning] Could not parse response into provided model. Returning raw content.")
            return content
    else:
        response = client.chat.completions.create(
            model=configs.LLM_MODEL,
            messages=message_history
        )
        content = response.choices[0].message.content.strip()

        # Save assistant reply to memory
        message_history.append({"role": "assistant", "content": content})

        print("[generate_completion] Finished generating plain text response.")
        return content


# ---------- SPEECH TO TEXT ----------

def transcribe_audio(
    audio_file_path: str
) -> str:
    """
    Transcribes speech from an audio file into text using OpenAI's models.

    Args:
        audio_file_path: Path to the input audio file (.mp3, .wav, etc.).

    Returns:
        A string containing the transcribed text.

    Example:
        >>> text = transcribe_audio("recordings/user_input.wav")
    """
    print(f"[transcribe_audio] Started transcribing: {audio_file_path}")

    with open(audio_file_path, "rb") as audio_file:
        transcription_response = client.audio.transcriptions.create(
            model=configs.TRANSCRIPTION_MODEL,
            file=audio_file,
            response_format="text"
        )

    print("[transcribe_audio] Finished transcribing audio.")
    return transcription_response


# ---------- TEXT TO SPEECH ----------

def synthesize_speech(
    text: str,
    output_dir: str = "voice/ai",
    voice: str = "coral",
    instructions: str = ""
) -> str:
    """
    Converts text into spoken audio using OpenAI's text-to-speech (TTS) API.

    Args:
        text: The text you want the AI to say aloud.
        output_dir: Folder where the generated .mp3 file should be saved.
        voice: The voice style to use (e.g., "nova", "onyx", "coral").
        instructions: (Optional) Customize the tone, emotion, or personality of the voice.

    Returns:
        The file path of the saved audio file.

    Example:
        >>> file_path = synthesize_speech("Hello, how are you today?")
    """
    print("[synthesize_speech] Started synthesizing speech...")

    os.makedirs(output_dir, exist_ok=True)
    filename = f"response_{datetime.now().strftime('%Y%m%d_%H%M%S')}.mp3"
    filepath = os.path.join(output_dir, filename)

    with client.audio.speech.with_streaming_response.create(
        model=configs.TEXT_TO_SPEECH_MODEL,
        voice=voice,
        input=text,
        instructions=instructions
    ) as response:
        response.stream_to_file(filepath)

    print(f"[synthesize_speech] Finished! Audio saved to: {filepath}")
    return filepath